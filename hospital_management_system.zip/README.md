# Hospital Management System

A simple hospital management system using Flask and SQLite.

## Setup

```bash
pip install -r requirements.txt
python app.py
```
